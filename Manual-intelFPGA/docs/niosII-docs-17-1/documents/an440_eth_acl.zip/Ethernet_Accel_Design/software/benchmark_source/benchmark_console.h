#ifndef BENCHMARK_CONSOLE_H_
#define BENCHMARK_CONSOLE_H_
int bmcommand_from_console(int nargc, char **nargv, struct command_def *command);

#endif /*BENCHMARK_CONSOLE_H_*/
