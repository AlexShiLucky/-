#!/bin/sh
#
# This file was automatically generated.
#
# It can be overwritten by nios2-flash-programmer-generate or nios2-flash-programmer-gui.
#

#
# Converting Binary File: Sys_Arch_Qsys/new/zip/tutorial/software/picture_viewer_bsp/jpeg_images.zip to: "../flash/jpeg_images_flash.flash"
#
/tools_archive/acds/11.0/157/linux32/nios2eds/bin/bin2flash --input="/data/kailng/Sys_Arch_Qsys/new/zip/tutorial/software/picture_viewer_bsp/jpeg_images.zip" --output="../flash/jpeg_images_flash.flash" --location=0x400000 --verbose 

#
# Programming File: "../flash/jpeg_images_flash.flash" To Device: flash
#
/tools_archive/acds/11.0/157/linux32/nios2eds/bin/nios2-flash-programmer "../flash/jpeg_images_flash.flash" --base=0x0 --sidp=0x1000800 --id=0x0 --timestamp=1305610891 --device=1 --instance=0 '--cable=USB-Blaster on 137.57.118.48 [USB-0]' --program --verbose 

