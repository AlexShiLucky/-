System Architect Tutorial readme.txt

This file contains the following sections:

o  Tool Requirements
o  Project Directory Names
o  Usage Instructions
o  Release History

Tool Requirements
=================

The examples in this archive require the following software tools:

- Quartus II software version 11.0 or later
- Nios II Embedded Design Suite (EDS) version 11.0 or later

This design also requires the following development board:

  - Nios II Embedded Evaluation Kit (NEEK), Cyclone III Edition

Project Directory Names
=======================

When you extract sys_arc_tutorial.zip the following folders will be created:

1. complete
2. tutorial
3. software_source_files
4. jpeg_images.zip


Usage Instructions
==================

To use the hardware and software examples in this archive, refer to 
"Nios II System Architect Design Tutorial"
(http://www.altera.com/literature/tt/tt_nios2_system_architect.pdf) 
available at :
http://www.altera.com/support/examples/nios2/exm-system-architect.html

complete directory contains the complete design which you can use 
immediately. You can use the SOF and ELF files included in the folder or 
you can regenerate the files using the steps below :
1. Generate the HDL files in Qsys.
2. Compile the hardware in Quartus II and configure NEEK with the SOF file.
3. Program the flash with jpeg_images.zip.
4. Import picture_viewer and picture_viewer_bsp into Software Build Tools for Eclipse.
5. Build project, download and run ELF file. 
You may refer Nios II System Architect Design Tutorial(PDF) for more 
detail steps.

tutorial directory contains a partial design which you need to follow
the steps in Nios II System Architect Design Tutorial(PDF) to complete
the design. Please refer Nios II System Architect Design Tutorial for details.

software_source_files contains the software source files which you need
as part of the tutorial steps.

jpeg_images.zip contains the image files which you need as part of the 
tutorial steps.

Release History
===============

Version 1.0
-------------

Initial release - for SOPC Builder 9.0


Version 2.0
-------------

Updated design for Qsys 11.0
Deleted SSRAM
Used hierarchy based design

Last updated June, 2011
Copyright � 2011 Altera Corporation. All rights reserved.
