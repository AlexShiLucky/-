This directory contains the script called create-this-bsp that builds
hal_default BSP.  To understand the simple sequence of operations
required to build a working board support package, please read the
contents of the create-this-bsp script.
